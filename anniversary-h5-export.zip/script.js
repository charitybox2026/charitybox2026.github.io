// script.js
document.addEventListener("DOMContentLoaded", () => {
    // 预处理所有需要打字的文本
    const typeTexts = document.querySelectorAll('.js-seq.type-text');
    typeTexts.forEach(el => {
        el.setAttribute('data-original-text', el.textContent);
        el.textContent = '';
    });
    // === 加载页逻辑 ===
    const loadingScreen = document.getElementById('loading-screen');
    
    // 模拟资源加载进度，2秒后淡出
    setTimeout(() => {
        loadingScreen.style.opacity = '0';
        
        // 淡出动画结束后(0.8s)隐藏 DOM，并初始化滑动插件
        setTimeout(() => {
            loadingScreen.style.display = 'none';
            initSwiper();
        }, 800);
    }, 2000);

    // === 滑动交互初始化 ===
    function initSwiper() {
        const swiper = new Swiper('.mySwiper', {
            direction: 'vertical', // 垂直全屏滑动
            mousewheel: true,      // 允许鼠标滚轮触发（方便桌面端预览测试）
            speed: 600,            // 切换速度
            on: {
                // 初始化完成时触发第一页的动画
                init: function () {
                    playSlideAnimation(this.activeIndex);
                },
                // 每次开始切换时重置所有动画，保证多次滑动依然有入场动效
                slideChangeTransitionStart: function () {
                    resetSlideAnimations();
                },
                // 切换结束时播放当前页的动画
                slideChangeTransitionEnd: function () {
                    playSlideAnimation(this.activeIndex);
                }
            }
        });
        
        window.anniversarySwiper = swiper; // 暴露给全局以便交互控制
        
        // 确保第一屏动画生效
        playSlideAnimation(swiper.activeIndex);
    }

    // 播放入场动画 (Fade-in + Slide-up)
    function playSlideAnimation(index) {
        const activeSlide = document.querySelectorAll('.swiper-slide')[index];
        if (!activeSlide) return;
        
        const content = activeSlide.querySelector('.content');
        if (content) {
            content.classList.remove('hidden');
            content.classList.add('active');
        }

        // --- 触发当前页面的数字滚动动画 (排除受控渐显的内容) ---
        const numberElements = activeSlide.querySelectorAll('.data-number:not(.type-fade)');
        if (numberElements.length > 0) {
            animateNumbers(numberElements);
        }
        
        // 触发 JS 依次打字机动效
        playTypewriterSequence(activeSlide);
    }

    // 重置动效至初始隐藏状态
    function resetSlideAnimations() {
        const contents = document.querySelectorAll('.swiper-slide .content');
        contents.forEach(content => {
            content.classList.remove('active');
            content.classList.add('hidden');
        });

        // --- 重置数字为 0 ---
        const numberElements = document.querySelectorAll('.data-number');
        numberElements.forEach(el => {
            el.innerText = '0';
        });

        // --- 重置打字机文本和隐藏层 ---
        const typeTexts = document.querySelectorAll('.js-seq.type-text');
        typeTexts.forEach(el => {
            el.textContent = '';
            el.classList.remove('typing-cursor');
        });
        const typeFades = document.querySelectorAll('.js-seq.type-fade');
        typeFades.forEach(el => {
            el.style.opacity = '0';
        });
    }

    // === JS 依次打字机动效 ===
    let currentSeqId = 0; // 防止快速滑动导致动画重叠

    function playTypewriterSequence(activeSlide) {
        const seqElements = activeSlide.querySelectorAll('.js-seq');
        if (seqElements.length === 0) return;

        currentSeqId++;
        const seqId = currentSeqId;
        let idx = 0;

        async function next() {
            if (seqId !== currentSeqId) return; // 用户已切走页面

            // 移除上一个元素的光标
            if (idx > 0) {
                seqElements[idx - 1].classList.remove('typing-cursor');
            }

            if (idx >= seqElements.length) {
                return; // 所有打字完毕
            }

            const el = seqElements[idx];

            if (el.classList.contains('type-text')) {
                // 如果还没有备份原始文本，在这里备份并清空
                if (!el.hasAttribute('data-original-text')) {
                    el.setAttribute('data-original-text', el.textContent.trim());
                    el.textContent = '';
                }
                
                el.classList.add('typing-cursor');
                const text = el.getAttribute('data-original-text') || '';
                let charIdx = 0;

                function typeChar() {
                    if (seqId !== currentSeqId) return;
                    if (charIdx < text.length) {
                        el.textContent += text.charAt(charIdx);
                        charIdx++;
                        setTimeout(typeChar, 40); 
                    } else {
                        idx++;
                        next(); 
                    }
                }
                typeChar();
            } else if (el.classList.contains('type-fade')) {
                el.style.opacity = '1';
                el.classList.add('active');
                
                // 如果是数字，等待数字滚动完成后再继续
                if (el.classList.contains('data-number')) {
                    await animateNumbers([el]);
                    setTimeout(() => {
                        idx++;
                        next();
                    }, 500); // 数字跳完后额外停顿 0.5s，增加体感层次
                } else {
                    setTimeout(() => {
                        idx++;
                        next();
                    }, 400);
                }
            } else {
                idx++;
                next();
            }
        }

        // 稍微延迟一下整体打字开始时间，配合 Slide-up 动画入场
        setTimeout(next, 600);
    }

    // === 数字翻滚动画函数 (返回 Promise 以便同步控制) ===
    function animateNumbers(elements) {
        const promises = Array.from(elements).map(el => {
            return new Promise((resolve) => {
                const targetStr = el.getAttribute('data-target');
                const target = parseFloat(targetStr);
                const isFloat = targetStr.includes('.'); // 判断是否需要保留小数
                const duration = 2000; // 动画时长 2s
                
                el.innerText = '0';
                let startTimestamp = null;
    
                const step = (timestamp) => {
                    if (!startTimestamp) startTimestamp = timestamp;
                    const progress = Math.min((timestamp - startTimestamp) / duration, 1);
                    
                    // 缓动函数 easeOutQuart 使得最后滚动变慢
                    const easeOut = 1 - Math.pow(1 - progress, 4);
                    const currentNumber = easeOut * target;
                    
                    // 格式化数字：添加千位分隔符，保留小数位如果是浮点数
                    const formatNum = (num, floatFlag) => {
                        return floatFlag 
                            ? num.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ",")
                            : Math.floor(num).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                    };

                    if (progress < 1) {
                        el.innerText = formatNum(currentNumber, isFloat);
                        window.requestAnimationFrame(step);
                    } else {
                        el.innerText = formatNum(target, isFloat); // 确保最终数字精确
                        resolve(); // 动画结束，Promise 完成
                    }
                };
                
                window.requestAnimationFrame(step);
            });
        });

        return Promise.all(promises);
    }

    // === 海报生成逻辑 (html2canvas) ===
    const btnGenerate = document.getElementById('btn-generate-poster');
    const loadingText = document.getElementById('poster-loading-text');
    
    if (btnGenerate) {
        btnGenerate.addEventListener('click', () => {
            // 防止重复点击
            btnGenerate.style.display = 'none';
            loadingText.style.display = 'block';
            
            // 目标截图区域为当前的整屏 Slide
            const targetElement = document.querySelector('.swiper-slide.ending-module');
            
            // 为了截取清晰，暂时移除会导致 html2canvas 渲染重影的 CSS 类
            const outlinedElements = targetElement.querySelectorAll('.heavy-outline, .heavy-outline-accent');
            outlinedElements.forEach(el => {
                el.classList.add('temp-no-outline');
                el.classList.remove('heavy-outline', 'heavy-outline-accent');
            });
            
            // 为了截取清晰，稍微延迟保证没有未完成的动效
            setTimeout(() => {
                html2canvas(targetElement, {
                    scale: 2, // 提高清晰度 (Retina)
                    useCORS: true, // 允许跨域图片
                    backgroundColor: '#FFF5D1' // 填充主背景色防透明
                }).then(canvas => {
                    // 截图完成后，恢复原有的文字描边样式
                    outlinedElements.forEach(el => {
                        el.classList.remove('temp-no-outline');
                        // 简单恢复一下重边框样式
                        el.style.textShadow = "2px 2px 0 #1a1a1a, -2px -2px 0 #1a1a1a, 2px -2px 0 #1a1a1a, -2px 2px 0 #1a1a1a";
                    });
                    // 转为 base64 图片格式
                    const imgData = canvas.toDataURL("image/png");
                    
                    // 创建一个结果展示容器遮盖全屏
                    const resultContainer = document.createElement('div');
                    resultContainer.style.position = 'absolute';
                    resultContainer.style.top = '0';
                    resultContainer.style.left = '0';
                    resultContainer.style.width = '100%';
                    resultContainer.style.height = '100%';
                    resultContainer.style.backgroundColor = 'rgba(0,0,0,0.85)';
                    resultContainer.style.zIndex = '9999';
                    resultContainer.style.display = 'flex';
                    resultContainer.style.flexDirection = 'column';
                    resultContainer.style.alignItems = 'center';
                    resultContainer.style.justifyContent = 'center';
                    
                    const resultImg = document.createElement('img');
                    resultImg.src = imgData;
                    resultImg.style.width = '85%';
                    resultImg.style.maxHeight = '80%';
                    resultImg.style.borderRadius = '10px';
                    resultImg.style.boxShadow = '0 0 20px rgba(255,255,255,0.3)';
                    resultImg.style.objectFit = 'contain';
                    
                    const hintText = document.createElement('p');
                    hintText.innerText = '长按上方海报保存图片分享';
                    hintText.style.color = '#fff';
                    hintText.style.marginTop = '15px';
                    hintText.style.fontSize = '14px';
                    hintText.style.fontFamily = "'Fusion Pixel 12px Proportional zh_hans', 'SimSun', sans-serif";
                    hintText.className = "pixel-en";
                    
                    // 提供一个关闭按钮
                    const closeBtn = document.createElement('button');
                    closeBtn.innerText = 'X 关闭';
                    closeBtn.style.marginTop = '15px';
                    closeBtn.style.padding = '8px 16px';
                    closeBtn.style.background = '#FF5A5F';
                    closeBtn.style.color = '#fff';
                    closeBtn.style.border = '2px solid #fff';
                    closeBtn.style.fontFamily = "'Fusion Pixel 12px Proportional zh_hans', 'SimSun', sans-serif";
                    closeBtn.style.borderRadius = '4px';
                    
                    closeBtn.addEventListener('click', () => {
                        targetElement.removeChild(resultContainer);
                        btnGenerate.style.display = 'inline-block';
                        loadingText.style.display = 'none';
                    });
                    
                    resultContainer.appendChild(resultImg);
                    resultContainer.appendChild(hintText);
                    resultContainer.appendChild(closeBtn);
                    
                    targetElement.appendChild(resultContainer);
                    
                    // 恢复按钮状态（被截图容器盖住不可见，但DOM状态需恢复）
                    loadingText.style.display = 'none';
                    
                }).catch(err => {
                    console.error("生成海报失败:", err);
                    alert("生成海报失败请重试。");
                    
                    // 出错也要恢复文字样式
                    outlinedElements.forEach(el => {
                        el.classList.remove('temp-no-outline');
                        el.style.textShadow = "2px 2px 0 #1a1a1a, -2px -2px 0 #1a1a1a, 2px -2px 0 #1a1a1a, -2px 2px 0 #1a1a1a";
                    });

                    btnGenerate.style.display = 'inline-block';
                    loadingText.style.display = 'none';
                });
            }, 300);
        });
    }


    // === 详情弹窗逻辑 ===
    const overlay = document.getElementById('detail-overlay');
    const modal = overlay.querySelector('.detail-modal');
    const closeModalBtn = overlay.querySelector('.modal-close-btn');
    
    // 给所有卡片绑定点击事件
    document.addEventListener('click', (e) => {
        const card = e.target.closest('.floating-card');
        if (card) {
            openDetail(card);
        }
    });

    function openDetail(card) {
        const title = card.querySelector('.card-title').textContent;
        const num = card.querySelector('.card-num').textContent;
        const detail = card.getAttribute('data-detail');
        
        // 填充弹窗内容
        overlay.querySelector('.modal-title').textContent = title.split('(')[0];
        overlay.querySelector('.modal-num').textContent = num;
        overlay.querySelector('.modal-unit').textContent = title.match(/\((.*?)\)/)?.[0] || '';
        overlay.querySelector('.modal-description').textContent = detail;
        
        // 显示弹窗
        overlay.classList.remove('hidden');
        // 强制重绘以触发 transition
        overlay.offsetHeight;
        overlay.classList.add('active');
        
        // 禁用 Swiper 滑动
        if (window.anniversarySwiper) {
            window.anniversarySwiper.allowTouchMove = false;
        }
    }

    function closeDetail() {
        overlay.classList.remove('active');
        setTimeout(() => {
            overlay.classList.add('hidden');
            // 恢复 Swiper 滑动
            if (window.anniversarySwiper) {
                window.anniversarySwiper.allowTouchMove = true;
            }
        }, 300);
    }

    // 点击关闭按钮或背景关闭
    closeModalBtn.addEventListener('click', closeDetail);
    overlay.addEventListener('click', (e) => {
        if (e.target === overlay) closeDetail();
    });
});

